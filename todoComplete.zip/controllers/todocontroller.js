
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

//Conectar a la BD de mlab
mongoose.connect(`mongodb://mongo:mongomon9@ds261570.mlab.com:61570/todobedu`)
.then(() => {
  console.log('Database connection successful')
})
.catch(err => {
  console.error('Database connection error')
})

let todoSchema = new mongoose.Schema({
    item: String
  })
let Todo = mongoose.model('Todo', todoSchema)
// var itemTest = Todo({item:'Prueba'})

// itemTest.save((err)=>{
//     if (err) throw err;
//     console.log('Item test guardado')
// })


let urlencodedParser= bodyParser.urlencoded({extended:false})
let data = [{item:'item 1'},{item:'todo 2'},{item:'todo 3'}]

module.exports = function(express){

    express.get('/todo',(req,res)=>{
        Todo.find({},(err,data)=>{
            // console.log(data)
            res.render('todo',{todos:data})
        })        
    });


    express.post('/todo',urlencodedParser,(req,res)=>{
        let newTodo = Todo(req.body)        
        newTodo.save((err,data)=>{
                if (err) throw err;
                console.log('Item nuevo guardado')
                res.json(data)
            })
        // let newItem = model.Todo(JSON.stringify(req.body))
        // data.push(req.body)        
        // console.log(req.body)
        // res.json(data)
    });

    express.delete('/todo/:item',(req,res)=>{
        console.log(req.params.item.replace(/\-/g,' '))    
        Todo.find({item: req.params.item.replace(/\-/g,'')},(err,data)=>{
            console.log(data)
        })
        Todo.find({item: req.params.item.replace(/\-/g,'')}).remove((err,data)=>{
            if (err) throw err;
            res.json(data)
        })

        // // console.log(`Parametros: ${JSON.stringify(req.params)}`) 
        // data= data.filter(todo=>{
        //     // console.log(todo.item.replace(/ /g,'-'))
        //     // console.log(req.params.item)
        //     return '-'+todo.item.replace(/ /g,'-') !== req.params.item;
        // })
        // res.json(data)
    });


}