/*Schema de la tarea por hacer */
const mongoose = require('mongoose');
let todoSchema = new mongoose.Schema({
    item: String
  })
module.exports = mongoose.model('Todo', todoSchema)
