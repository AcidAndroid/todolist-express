let data = [{item:'item 1'},{item:'todo 2'},{item:'todo 3'}]
const bodyParser = require('body-parser');
let urlencodedParser= bodyParser.urlencoded({extended:false})


module.exports = function(express,model){

    express.get('/todo',(req,res)=>{
        res.render('todo',{todos:data})
    });


    express.post('/todo',urlencodedParser,(req,res)=>{
        // let newItem = model.Todo(JSON.stringify(req.body))
        data.push(req.body)
        console.log(model.typeOf)
        // console.log(req.body)
        res.json(data)
    });

    express.delete('/todo/:item',(req,res)=>{
        // console.log(`Parametros: ${JSON.stringify(req.params)}`) 
        data= data.filter(todo=>{
            // console.log(todo.item.replace(/ /g,'-'))
            // console.log(req.params.item)
            return '-'+todo.item.replace(/ /g,'-') !== req.params.item;
        })
        res.json(data)
    });


}